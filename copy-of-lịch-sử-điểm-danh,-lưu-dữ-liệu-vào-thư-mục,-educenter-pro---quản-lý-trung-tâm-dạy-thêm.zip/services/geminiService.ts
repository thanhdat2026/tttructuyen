// Các tính năng tích hợp Gemini AI đã được gỡ bỏ khỏi ứng dụng.
